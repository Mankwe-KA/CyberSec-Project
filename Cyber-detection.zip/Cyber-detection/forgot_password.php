<?php
// Start PHP session
session_start();

// Database connection
$host = 'localhost'; 
$dbname = 'cybersecdb'; 
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);

    if ($email) {
        // Check if the email exists in the database
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Generate a secure reset token
            $resetToken = bin2hex(random_bytes(16));
            $tokenExpiry = date("Y-m-d H:i:s", strtotime('+1 hour'));

            // Update database with reset token and expiry
            $stmt = $pdo->prepare("UPDATE users SET reset_token = :reset_token, token_expiry = :token_expiry WHERE email = :email");
            $stmt->execute([
                'reset_token' => $resetToken,
                'token_expiry' => $tokenExpiry,
                'email' => $email
            ]);

            // Send reset email
            $resetLink = "http://localhost/reset_password.php?token=$resetToken";
            $subject = "Password Reset Request";
            $message = "Hi,\n\nClick the link below to reset your password:\n$resetLink\n\nThis link will expire in 1 hour.\n\nRegards,\nCyberSec Team";
            $headers = "From: no-reply@cybersec.com";

            if (mail($email, $subject, $message, $headers)) {
                $_SESSION['success'] = "Reset link sent successfully. Please check your email!";
            } else {
                $_SESSION['error'] = "Failed to send reset link. Please try again.";
            }
        } else {
            $_SESSION['error'] = "Email address not found.";
        }
    } else {
        $_SESSION['error'] = "Please enter a valid email address.";
    }

    header("Location: forgot_password.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - CyberSec</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .forgot-password-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .forgot-password-container h2 {
            color: #3498db;
            margin-bottom: 20px;
        }

        .forgot-password-container input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
        }

        .forgot-password-container button {
            width: 100%;
            padding: 12px;
            background-color: #3498db;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .forgot-password-container .message {
            margin-top: 10px;
            font-size: 14px;
        }

        .forgot-password-container .success {
            color: #2ecc71;
        }

        .forgot-password-container .error {
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class="forgot-password-container">
        <h2>Forgot Password</h2>
        <p>Enter your email address, and we'll send you a link to reset your password.</p>
        <?php if (isset($_SESSION['success'])): ?>
            <p class="message success"><?= $_SESSION['success'] ?></p>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <p class="message error"><?= $_SESSION['error'] ?></p>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        <form method="POST" action="">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Send Reset Link</button>
        </form>
    </div>
</body>
</html>
