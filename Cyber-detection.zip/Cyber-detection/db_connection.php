<?php
// db_connection.php
$servername = "localhost";
$username = "root"; //database username
$password = "";     //database password
$dbname = "cybersecdb"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
