<?php
session_start();
// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: admin_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CyberSec</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f4f6f9;
            color: #333;
        }

        /* Sidebar Styles */
        .sidebar {
            background-color: #1e1e2d;
            color: white;
            width: 220px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: fixed;
            height: 100vh;
            box-sizing: border-box;
        }

        .sidebar h2 {
            margin: 0 0 30px;
            font-size: 1.3em;
            color: #FF5733;
            text-align: center;
        }

        .sidebar a {
            color: #ddd;
            text-decoration: none;
            font-size: 1em;
            padding: 10px 15px;
            width: 100%;
            border-radius: 5px;
            margin: 8px 0;
            display: flex;
            align-items: center;
            transition: background-color 0.3s, color 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background-color: #2f2f44;
            color: #FF5733;
        }

        .sidebar a .icon {
            margin-right: 10px;
            font-size: 1.1em;
        }

        /* Main Content */
        .main-content {
            margin-left: 240px;
            padding: 30px;
            flex: 1;
            display: flex;
            flex-direction: column;
            max-width: 1200px;
        }

        .top-bar {
            background-color: #ffffff;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .top-bar h1 {
            margin: 0;
            color: #FF5733;
            font-size: 1.6em;
        }

        #timestamp {
            color: #555;
            font-size: 0.9em;
            font-weight: 500;
        }

        .overview-cards {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .card {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            flex: 1 1 260px;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
            cursor: pointer;
        }

        .card:hover { transform: translateY(-5px); }

        .chart-container {
            margin-top: 30px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 1000px;
            box-sizing: border-box;
        }

        .footer {
            text-align: center;
            padding: 15px;
            background-color: #282c34;
            color: #ffffff;
            margin-top: auto;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <h2>CyberSec Admin</h2>
        <a href="admin_dashboard.php" class="active"><span class="icon">📊</span> Dashboard</a>
        <a href="user_management.php"><span class="icon">👤</span> User Management</a>
        <a href="system_logs.php"><span class="icon">📜</span> System Logs</a>
        <a href="settings.php"><span class="icon">⚙️</span> Settings</a>
        <a href="reports.php"><span class="icon">📈</span> Reports</a>
        <a href="logout.php"><span class="icon">🔓</span> Logout</a>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
        <header class="top-bar">
            <h1>Welcome, Admin!</h1>
            <span id="timestamp">Last Updated: Loading...</span>
        </header>

        <section class="overview-cards">
            <div class="card">
                <h3>User Management</h3>
                <p>Manage user accounts, permissions, and roles.</p>
            </div>
            <div class="card">
                <h3>System Logs</h3>
                <p>Review system logs to monitor activity and ensure security.</p>
            </div>
            <div class="card">
                <h3>Settings</h3>
                <p>Configure system settings, preferences, and alerts.</p>
            </div>
        </section>

        <div class="chart-container">
            <h3>Threat Detection Trends</h3>
            <canvas id="threatChart"></canvas>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 CyberSec Threat Detection System. All rights reserved.</p>
    </footer>

    <!-- Chart and Timestamp Script -->
    <script>
        // Update timestamp every second
        function updateTimestamp() {
            const now = new Date();
            const timestamp = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB');
            document.getElementById('timestamp').textContent = 'Last Updated: ' + timestamp;
        }
        setInterval(updateTimestamp, 1000);

        // Threat Detection Trends Line Chart
        const ctx = document.getElementById('threatChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Detected Threats (Count)',
                    data: [20, 30, 25, 35, 50, 40, 55, 45, 60, 70, 65, 80],
                    borderColor: '#FF5733',
                    backgroundColor: 'rgba(255, 87, 51, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                },
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });
    </script>
</body>
</html>
