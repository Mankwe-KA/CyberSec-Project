<?php
// user_dashboard.php
include 'db_connection.php';

session_start();
$user_id = $_SESSION['user_id']; // Ensure the user ID is stored in the session upon login

// Fetch user data from the database
$user_query = "SELECT username, profile_picture, cpu_usage, memory_usage FROM users WHERE id = ?";
$statement = $conn->prepare($user_query);
$statement->bind_param("i", $user_id);
$statement->execute();
$user_result = $statement->get_result()->fetch_assoc();

$threat_query = "SELECT threat_level, severity_status FROM threats WHERE user_id = ? ORDER BY date DESC LIMIT 1";
$statement = $conn->prepare($threat_query);
$statement->bind_param("i", $user_id);
$statement->execute();
$threat_result = $statement->get_result()->fetch_assoc();

// Return JSON for JavaScript to use
echo json_encode([
    "username" => $user_result['username'],
    "profile_picture" => $user_result['profile_picture'],
    "cpu_usage" => $user_result['cpu_usage'],
    "memory_usage" => $user_result['memory_usage'],
    "threat_level" => $threat_result['threat_level'],
    "severity_status" => $threat_result['severity_status']
]);
?>
