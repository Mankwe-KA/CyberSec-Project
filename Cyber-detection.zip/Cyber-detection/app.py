from flask import Flask, request, jsonify
import tensorflow as tf
import numpy as np

# Load the model
model = tf.keras.models.load_model('cybersecurity_threat_detection_model.h5')

# Initialize Flask app
app = Flask(__name__)

# Define a route for predictions
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get JSON data from request
        data = request.json
        features = np.array(data['features']).reshape(1, -1)

        # Make prediction
        prediction = model.predict(features)
        predicted_class = np.argmax(prediction, axis=1)[0]  # For classification models, get the class with highest probability

        # Respond with the prediction
        return jsonify({'prediction': int(predicted_class)})

    except Exception as e:
        return jsonify({'error': str(e)})

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
