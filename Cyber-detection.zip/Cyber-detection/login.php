<?php
// Start session to store user data after login
session_start();

// Database connection setup
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cybersecdb";  

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize error message
$error_message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT id, username, password_hash FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Check if user exists
    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $username, $hashed_password);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Set session variables
            $_SESSION["user_id"] = $id;
            $_SESSION["username"] = $username;

            // Redirect to dashboard or any other protected page
            header("Location: dashboard.html");
            exit();
        } else {
            // Incorrect password
            $error_message = "Invalid username or password.";
        }
    } else {
        // User not found
        $error_message = "Invalid username or password.";
    }

    // Close the statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CyberSec</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* General Styles */
        body {
            font-family: 'Roboto', Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            align-items: center;
            justify-content: center;
            color: #333;
        }

        .top-nav {
            position: absolute;
            top: 0;
            width: 100%;
            background-color: #1e1e2d;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-size: 1.2em;
        }

        .top-nav .logo {
            font-size: 24px;
            font-weight: 700;
            color: #FF5733;
        }

        .top-nav nav a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .top-nav nav a:hover {
            color: #FF5733;
        }

        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin-top: 80px;
            transition: transform 0.3s;
        }

        .login-container:hover {
            transform: translateY(-5px);
        }

        .login-container h2 {
            color: #3498db;
            margin-bottom: 20px;
            font-size: 1.8em;
        }

        .login-container label {
            display: block;
            text-align: left;
            margin: 10px 0 5px;
            font-weight: 500;
            color: #333;
        }

        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        .login-container input[type="text"]:focus,
        .login-container input[type="password"]:focus {
            border-color: #3498db;
            outline: none;
        }

        .login-container button {
            width: 100%;
            padding: 12px;
            background-color: #3498db;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .login-container button:hover {
            background-color: #2980b9;
        }

        .login-container p#error-message {
            color: #e74c3c;
            font-size: 14px;
            margin-top: 10px;
        }

        .footer {
            width: 100%;
            background-color: #1e1e2d;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: auto;
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
        }

        .footer p {
            margin: 0;
            font-size: 1em;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <header class="top-nav">
        <div class="logo">CyberSec</div>
        <nav>
            <a href="index.html">Home</a>
        </nav>
    </header>
    
    <!-- Login Container -->
    <div class="login-container">
        <h2>Login to CyberSec</h2>
        <form action="" method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required placeholder="Enter your username">
            
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required placeholder="Enter your password">
            
            <button type="submit">Login</button>
        </form>
        <?php if ($error_message): ?>
            <p id="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 CyberSec. All rights reserved.</p>
    </footer>
</body>
</html>
