<?php
$responseText = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $features = $_POST['features'];
    $data = ["features" => array_map('floatval', $features)]; // Convert to JSON-compatible data

    $jsonData = json_encode($data);

    $ch = curl_init('http://localhost:5000/predict');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $responseText = 'Error:' . curl_error($ch);
    } else {
        $result = json_decode($response, true);
        $responseText = 'Prediction: ' . $result['prediction'];
    }

    curl_close($ch);
}
