<?php
require 'Threat.php';

$threatModel = new Threat($pdo);
$threats = $threatModel->getThreats();
echo json_encode($threats);
?>
