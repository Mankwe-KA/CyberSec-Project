-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: [Current Date & Time]
-- Server version: 8.0.x
-- PHP Version: 7.4.x

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Table structure for `roles`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_name` VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`role_name`) VALUES
  ('Administrator'),
  ('User');

-- --------------------------------------------------------
-- Table structure for `users`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL, -- Secure hashed passwords
  `role_id` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`username`, `email`, `password`, `role_id`) VALUES
  ('admin', 'admin@cybersec.com', '83ec45960b80c035a0068df1d9df5aa8', 1),
  ('kgothatso', 'kgothatsoangelina15@gmail.com', '83ec45960b80c035a0068df1d9df5aa8', 2),
  ('Kamogelo', 'Kamogelobless@gmail.com', '83ec45960b80c035a0068df1d9df5aa8', 2);

-- --------------------------------------------------------
-- Table structure for `system_logs`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `system_logs` (
  `log_id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT,
  `event` VARCHAR(100) NOT NULL,
  `details` TEXT,
  `log_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `system_logs` (`user_id`, `event`, `details`) VALUES
  (1, 'Login', 'User admin logged in'),
  (2, 'Login', 'User kgothatso logged in'),
  (1, 'Password Change', 'Admin changed the password');

-- --------------------------------------------------------
-- Table structure for `alerts`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `alerts` (
  `alert_id` INT AUTO_INCREMENT PRIMARY KEY,
  `alert_type` VARCHAR(50) NOT NULL,
  `alert_message` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `alerts` (`alert_type`, `alert_message`) VALUES
  ('Malware Alert', 'Suspicious malware detected in the system.'),
  ('Network Anomaly', 'Unusual network activity detected.'),
  ('Login Attempt', 'Multiple failed login attempts detected.');

-- --------------------------------------------------------
-- Table structure for `contact_info`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `contact_info` (
  `contact_id` INT AUTO_INCREMENT PRIMARY KEY,
  `contact_address` VARCHAR(100) NOT NULL,
  `contact_mail` VARCHAR(50) NOT NULL,
  `contact_phone` VARCHAR(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `contact_info` (`contact_address`, `contact_mail`, `contact_phone`) VALUES 
  ('CyberSec HQ, 123 Tech Lane', 'support@cybersec.com', '+1234567890');

-- --------------------------------------------------------
-- Table structure for `pages`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pages` (
  `page_id` INT AUTO_INCREMENT PRIMARY KEY,
  `page_name` VARCHAR(100) NOT NULL,
  `page_type` VARCHAR(50) NOT NULL UNIQUE,
  `page_data` LONGTEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `pages` (`page_name`, `page_type`, `page_data`) VALUES
  ('About CyberSec', 'about', 'CyberSec is a cybersecurity platform that protects businesses...'),
  ('Contact Information', 'contact', 'You can reach us at support@cybersec.com.');

-- --------------------------------------------------------
-- Table structure for `threat_data`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `threat_data` (
  `threat_id` INT AUTO_INCREMENT PRIMARY KEY,
  `threat_type` VARCHAR(50) NOT NULL,
  `severity` ENUM('Low', 'Medium', 'High') NOT NULL,
  `description` TEXT NOT NULL,
  `detected_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `threat_data` (`threat_type`, `severity`, `description`) VALUES
  ('Malware', 'High', 'Detected malware in email attachment.'),
  ('Brute Force', 'Medium', 'Multiple failed login attempts.'),
  ('Phishing', 'Low', 'Phishing email targeting users.');

-- --------------------------------------------------------
-- Table structure for `settings`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `setting_id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_name` VARCHAR(50) NOT NULL UNIQUE,
  `setting_value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `settings` (`setting_name`, `setting_value`) VALUES
  ('Default Password Policy', 'Minimum 8 characters, at least 1 uppercase, 1 number, 1 special character'),
  ('System Maintenance Time', 'Sunday 2 AM to 4 AM');
