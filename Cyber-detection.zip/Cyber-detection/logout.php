<?php
// Start the session
session_start();

// Destroy all session data to log out the user
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - Cybersecurity Threat Detection System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* General Styles */
        body {
            font-family: 'Roboto', Arial, sans-serif;
            background-color: #f4f6f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .logout-message {
            text-align: center;
            background-color: white;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            animation: fadeIn 0.6s ease;
            position: relative;
        }

        .logout-message .icon {
            font-size: 50px;
            color: #e74c3c;
            animation: bounce 1s infinite;
            margin-bottom: 20px;
        }

        .logout-message h2 {
            color: #e74c3c;
            font-size: 24px;
            margin-bottom: 15px;
        }

        .logout-message p {
            font-size: 16px;
            color: #666;
            margin-bottom: 20px;
        }

        .logout-message button {
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 600;
            color: white;
            background-color: #3498db;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .logout-message button:hover {
            background-color: #2980b9;
        }

        /* Fade In Animation */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Icon Bounce Animation */
        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }
    </style>
</head>
<body>
    <div class="logout-message">
        <div class="icon">🔒</div>
        <h2>Logged Out Successfully</h2>
        <p>You have been logged out of the Cybersecurity Threat Detection System.</p>
        <p>Redirecting to the Home page...</p>
        <button onclick="window.location.href='home.html'">Go to Home Now</button>
    </div>

    <script>
        // Redirect to home.html after a delay
        setTimeout(() => {
            window.location.href = 'home.html';
        }, 3000); // Redirect after 3 seconds
    </script>
</body>
</html>
