<?php
// Include database connection
include 'db_connection.php';

// Start session
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Access denied. Please log in.");
}

$is_admin = $_SESSION['role'] === 'admin'; // Check if the user is an admin
$user_id = $_SESSION['user_id']; // Get logged-in user ID

// Fetch logs from the database
$query = $is_admin ? "SELECT * FROM system_logs ORDER BY event_time DESC" :
    "SELECT * FROM system_logs WHERE user_id = ? ORDER BY event_time DESC";

$logs = [];
if ($stmt = $conn->prepare($query)) {
    if (!$is_admin) $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $logs[] = [
            "date" => date("Y-m-d", strtotime($row['event_time'])),
            "time" => date("H:i", strtotime($row['event_time'])),
            "event" => $row['event_type'],
            "details" => $row['event_details']
        ];
    }
    $stmt->close();
} else {
    die("Failed to fetch logs.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Logs - CyberSec Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <style>
        body { font-family: 'Roboto', sans-serif; margin: 0; display: flex; background-color: #f4f6f9; color: #333; }
        .sidebar { background-color: #1e1e2d; color: white; width: 250px; padding: 20px; display: flex; flex-direction: column; align-items: center; height: 100vh; position: fixed; left: 0; top: 0; bottom: 0; }
        .sidebar a { color: #ddd; text-decoration: none; font-size: 1.1em; padding: 12px 20px; width: 100%; border-radius: 5px; margin: 10px 0; display: flex; align-items: center; transition: background-color 0.3s, color 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #2f2f44; color: #FF5733; }
        .content { margin-left: 270px; padding: 40px; flex: 1; }
        h1 { color: #FF5733; }
        .log-list { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); }
        .log-list table { width: 100%; border-collapse: collapse; }
        .log-list th, .log-list td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        .export-buttons { display: flex; gap: 10px; margin-top: 20px; }
        .export-buttons button { padding: 10px 15px; background-color: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .export-buttons button:hover { background-color: #2980b9; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <h2>CyberSec Admin</h2>
        <a href="admin_dashboard.php">📊 Dashboard</a>
        <a href="user-management.php">👤 User Management</a>
        <a href="system_logs.php" class="active">📜 System Logs</a>
        <a href="settings.php">⚙️ Settings</a>
        <a href="logout.php">🔓 Logout</a>
    </aside>

    <!-- Main Content -->
    <div class="content">
        <h1>System Logs</h1>
        <div class="log-list">
            <h2>Recent Logs</h2>
            <table id="logTable">
                <thead>
                    <tr><th>Date</th><th>Time</th><th>Event</th><th>Details</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= $log['date'] ?></td>
                            <td><?= $log['time'] ?></td>
                            <td><?= $log['event'] ?></td>
                            <td><?= $log['details'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="export-buttons">
                <button onclick="exportToCSV()">Export to CSV</button>
                <button onclick="exportToPDF()">Export to PDF</button>
            </div>
        </div>
    </div>

    <!-- JavaScript for Export Functions -->
    <script>
        // Export to CSV
        function exportToCSV() {
            let csvContent = "data:text/csv;charset=utf-8,Date,Time,Event,Details\n";
            const rows = document.querySelectorAll("#logTable tbody tr");
            rows.forEach(row => {
                const columns = row.querySelectorAll("td");
                const rowData = Array.from(columns).map(column => column.textContent).join(",");
                csvContent += rowData + "\n";
            });
            const link = document.createElement("a");
            link.setAttribute("href", encodeURI(csvContent));
            link.setAttribute("download", "system_logs.csv");
            link.click();
        }

        // Export to PDF
        function exportToPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            doc.setFontSize(16);
            doc.text("System Logs", 14, 16);
            doc.setFontSize(12);
            doc.text("Date       Time       Event       Details", 14, 26);
            const rows = document.querySelectorAll("#logTable tbody tr");
            let yPos = 36;
            rows.forEach(row => {
                const columns = row.querySelectorAll("td");
                const rowData = Array.from(columns).map(column => column.textContent);
                doc.text(rowData.join("       "), 14, yPos);
                yPos += 10;
            });
            doc.save("system_logs.pdf");
        }
    </script>
</body>
</html>
