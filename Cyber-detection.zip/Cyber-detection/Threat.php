<?php
require 'db.php';

class Threat {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getThreats($limit = 10) {
        $stmt = $this->pdo->prepare("SELECT * FROM threats ORDER BY detected_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
