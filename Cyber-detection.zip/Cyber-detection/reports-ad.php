<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - CyberSec Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    <style>
        body { font-family: 'Roboto', sans-serif; margin: 0; display: flex; background-color: #f4f6f9; color: #333; }
        .sidebar { background-color: #1e1e2d; color: white; width: 250px; padding: 20px; position: fixed; height: 100vh; }
        .sidebar h2 { font-size: 1.3em; color: #FF5733; text-align: center; }
        .sidebar a { color: #ddd; text-decoration: none; font-size: 1em; padding: 10px 15px; border-radius: 5px; margin: 8px 0; display: flex; align-items: center; transition: background-color 0.3s, color 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #2f2f44; color: #FF5733; }
        .content { margin-left: 270px; padding: 40px; flex: 1; display: flex; flex-direction: column; align-items: center; }
        .header { display: flex; justify-content: space-between; align-items: center; width: 100%; padding: 20px 0; }
        .header h1 { margin: 0; color: #FF5733; }
        .report-cards { display: flex; gap: 20px; flex-wrap: wrap; justify-content: center; }
        .card { background-color: #ffffff; border-radius: 8px; padding: 20px; flex: 1 1 250px; min-width: 250px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); transition: transform 0.2s; }
        .card:hover { transform: translateY(-5px); }
        .chart-container { margin-top: 30px; background-color: #ffffff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); width: 100%; max-width: 600px; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <h2>CyberSec Admin</h2>
        <a href="admin_dashboard.html">📊 Dashboard</a>
        <a href="user-management.html">👤 User Management</a>
        <a href="system-logs.html">📜 System Logs</a>
        <a href="settings.html">⚙️ Settings</a>
        <a href="reports-ad.html" class="active">📈 Reports</a>
        <a href="index.html">🔓 Logout</a>
    </aside>

    <!-- Main Content -->
    <div class="content" id="report-section">
        <div class="header">
            <h1>Monthly Summary Report</h1>
            <div>
                <button onclick="downloadPDF()">Download as PDF</button>
                <button onclick="downloadExcel()">Download as Excel</button>
            </div>
        </div>

        <p>This report provides an overview of key statistics for the current month, including total active users, threats detected, alerts generated, and account activity. Generated on: <span id="currentDate"></span>.</p>

        <section class="report-cards">
            <div class="card">
                <h3>Total Active Users</h3>
                <p>Current Month: <strong>5</strong></p>
            </div>
            <div class="card">
                <h3>Threats Detected</h3>
                <p>This Month: <strong>65</strong></p>
            </div>
            <div class="card">
                <h3>Alerts Generated</h3>
                <p>Last 7 Days: <strong>25</strong></p>
            </div>
            <div class="card">
                <h3>Account Activities</h3>
                <p>Logins This Month: <strong>300</strong></p>
            </div>
        </section>

        <div class="chart-container">
            <h3>Monthly Summary Chart</h3>
            <canvas id="summaryChart"></canvas>
        </div>
    </div>

    <!-- JavaScript for PDF and Excel Export -->
    <script>
        document.getElementById("currentDate").textContent = new Date().toLocaleString();

        // Chart Data
        const ctx = document.getElementById('summaryChart').getContext('2d');
        const summaryChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Total Active Users', 'Threats Detected', 'Alerts Generated', 'Account Activities'],
                datasets: [{
                    label: 'Monthly Data',
                    data: [5, 65, 25, 300],
                    backgroundColor: ['#FF5733', '#3498db', '#f1c40f', '#2ecc71']
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Download PDF
        function downloadPDF() {
            const element = document.getElementById("report-section");
            const opt = {
                margin: [0.5, 0.5, 0.5, 0.5],
                filename: "Monthly_Summary_Report.pdf",
                image: { type: "jpeg", quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
                pagebreak: { mode: ["css", "avoid-all", "legacy"] }
            };

            html2pdf().set(opt).from(element).save();
        }

        // Download as Excel
        function downloadExcel() {
            // Convert chart to image and prepare data
            const chartImage = summaryChart.toBase64Image();
            const wb = XLSX.utils.book_new();
            const ws = XLSX.utils.aoa_to_sheet([
                ["Metric", "Value"],
                ["Total Active Users", "5"],
                ["Threats Detected", "65"],
                ["Alerts Generated", "25"],
                ["Account Activities", "300"]
            ]);

            // Add data and image
            XLSX.utils.book_append_sheet(wb, ws, "Summary Data");

            // Add image as chart (positioned separately)
            const img = new Image();
            img.src = chartImage;
            img.onload = function() {
                const canvas = document.createElement("canvas");
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext("2d");
                ctx.drawImage(img, 0, 0);

                XLSX.writeFile(wb, "Monthly_Summary_Report.xlsx");
            };
        }
    </script>
</body>
</html>
