<?php
// Set headers for JSON response
header('Content-Type: application/json');

try {
    
    $pdo = new PDO('mysql:host=localhost;dbname=cybersec', 'root', '');

    
    $stmt = $pdo->query('SELECT * FROM traffic_data ORDER BY timestamp DESC LIMIT 20');
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return data as JSON
    echo json_encode($data);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
