<?php
// Include database connection
include 'db_connection.php';

// Start session
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Access denied. Please log in.");
}

$user_id = $_SESSION['user_id'];

// Handle profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];

    // Handle profile picture update
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === 0) {
        $target_dir = "uploads/";
        $file_name = $user_id . "_profile." . pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
        $target_file = $target_dir . $file_name;

        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
            $stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
            $stmt->bind_param("si", $target_file, $user_id);
            $stmt->execute();
            $response['success'] = true;
            $response['message'] = "Profile picture updated successfully.";
        } else {
            $response['message'] = "Failed to upload profile picture.";
        }
    }

    // Handle password update
    if (!empty($_POST['password']) && $_POST['password'] === $_POST['confirm_password']) {
        $password_hash = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $password_hash, $user_id);
        $stmt->execute();

        $response['success'] = true;
        $response['message'] = "Password updated successfully.";
    } else {
        $response['message'] = "Passwords do not match or are invalid.";
    }

    echo json_encode($response);
    exit;
}

// Fetch user data
$stmt = $conn->prepare("SELECT username, profile_picture FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - CyberSec Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* CSS styles here */
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <h2>CyberSec Admin</h2>
        <a href="admin_dashboard.php">📊 Dashboard</a>
        <a href="user-management.php">👤 User Management</a>
        <a href="system-logs.php">📜 System Logs</a>
        <a href="settings-ad.php" class="active">⚙️ Settings</a>
        <a href="logout.php">🔓 Logout</a>
    </aside>

    <!-- Main Content -->
    <div class="content">
        <h1>Settings</h1>
        <div class="settings-form">
            <h2>Update Profile</h2>
            <form id="settingsForm" enctype="multipart/form-data">
                <div class="profile-picture">
                    <img src="<?= $user_data['profile_picture'] ?: 'default-avatar.png'; ?>" alt="Profile Picture" id="profilePic">
                    <input type="file" id="profilePicture" name="profile_picture" accept="image/*">
                </div>

                <label for="username">Username:</label>
                <input type="text" id="username" value="<?= $user_data['username']; ?>" disabled>

                <label for="password">New Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter new password" required>

                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirmPassword" name="confirm_password" placeholder="Confirm new password" required>

                <button type="submit">Save Changes</button>

                <!-- Messages -->
                <div class="message success-message" id="successMessage">Profile updated successfully!</div>
                <div class="message error-message" id="errorMessage">Failed to update profile. Please try again.</div>
            </form>
        </div>
    </div>

    <script>
        const form = document.getElementById('settingsForm');
        const successMessage = document.getElementById('successMessage');
        const errorMessage = document.getElementById('errorMessage');

        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const formData = new FormData(form);

            try {
                const response = await fetch('settings-ad.php', {
                    method: 'POST',
                    body: formData,
                });
                const result = await response.json();

                if (result.success) {
                    successMessage.style.display = 'block';
                    errorMessage.style.display = 'none';
                    setTimeout(() => successMessage.style.display = 'none', 3000);
                } else {
                    successMessage.style.display = 'none';
                    errorMessage.style.display = 'block';
                    setTimeout(() => errorMessage.style.display = 'none', 3000);
                }
            } catch (error) {
                console.error('Error:', error);
                successMessage.style.display = 'none';
                errorMessage.style.display = 'block';
            }
        });
    </script>
</body>
</html>
